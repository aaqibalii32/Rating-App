<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ratingapp</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<script src="<?php echo site_url('resources/js/jquery-2.2.3.min.js'); ?>"></script>

	<!-- Bootstrap 3.3.6 -->
	<link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" href="<?php echo site_url('resources/css/custom.css'); ?>">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?php echo site_url('resources/css/font-awesome.min.css'); ?>">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
	<!-- Datetimepicker -->
	<link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap-datetimepicker.min.css'); ?>">
	<!-- Theme style -->
	<link rel="stylesheet" href="<?php echo site_url('resources/css/AdminLTE.min.css'); ?>">
	<script src="<?= base_url('resources/js/select2.min.js') ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?= base_url('resources/css/') ?>select2.min.css" />
	<!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
	<link rel="stylesheet" href="<?php echo site_url('resources/css/_all-skins.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('resources/css/') ?>dataTables.bootstrap.min.css" />
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.bootstrap4.min.js"> </script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"> </script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"> </script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"> </script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"> </script>
	<style>
		body{
			background: lightblue;
		}
		.box {
			position: relative;
			border-radius: 3px;
			background: #f6f0f0;
			border-top: 3px solid #d2d6de;
			margin-bottom: 20px;
			width: 100%;
			box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
		}
	</style>
</head>

<body class="hold-transition skin-blue sidebar-mini">
	<h1>Rating</h1>
	<div class="row">

		<div class="col-md-12">
			<div class="box box-info">
				<!-- <div class="box-header with-border">
					<h3 class="box-title"></h3>
				</div> -->
				<?php echo form_open('rating/add/' . $staff_id, array('id' => 'myform')); ?>
				<div class="box-body">
					<div class="row clearfix">
						<div class="col-md-3">
							<label for="staff" class="control-label">Staff <span class="text-danger">*</span></label>
							<div class="form-group">
								<select name="staff" id="staff" disabled class="form-control">
									<option value="">Select Staff </option>
									<?php
									foreach ($staff as $s) {
										$selected = ($s['id'] == $staff_id) ? ' selected="selected"' : "";

										echo '<option value="' . $s['id'] . '" ' . $selected . '>' . $s['full_name'] . '</option>';
									}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Rating Category <span class="text-danger">*</span></label>
							<div class="form-group">
								<select name="rating_type" id="rating_type" class="form-control">
									<option value="">Select Rating Category </option>
									<?php
									foreach ($all_rating_category as $rating_category) {
										$selected = ($rating_category['id'] == $this->input->post('rating_type')) ? ' selected="selected"' : "";

										echo '<option value="' . $rating_category['id'] . '" ' . $selected . '>' . $rating_category['name'] . '</option>';
									}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<label for="reason" class="control-label">Feedback</label>
							<div class="form-group">
								<textarea name="reason" class="form-control" id="reason"><?php echo $this->input->post('reason'); ?></textarea>
							</div>
						</div>
					</div>
				</div>
				<div class="box-footer">
					<button type="button" onclick="$('#userinfo').show(300);$(this).hide();" class="btn btn-success">
						<!-- <i class="fa fa-check"></i>  -->
						Continue
					</button>
				</div>
			</div>
		</div>
	</div>
	<div class="row" id="userinfo" style="display: none">
		<div class="col-md-12">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Customer Info</h3>
				</div>
				<div class="box-body">
					<div class="row clearfix">
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Forename</label>
							<div class="form-group">
								<input type="text" name="forename" class="form-control" value="<?php echo $this->input->post('forename'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">First Name</label>
							<div class="form-group">
								<input type="text" name="first_name" class="form-control" value="<?php echo $this->input->post('first_name'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Last Name</label>
							<div class="form-group">
								<input type="text" name="last_name" class="form-control" value="<?php echo $this->input->post('last_name'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Mobile No</label>
							<div class="form-group">
								<input type="text" name="no" class="form-control" value="<?php echo $this->input->post('no'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">City</label>
							<div class="form-group">
								<input type="text" name="city" class="form-control" value="<?php echo $this->input->post('city'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Vehicle Type</label>
							<div class="form-group">
								<input type="text" name="v_type" class="form-control" value="<?php echo $this->input->post('v_type'); ?>" />
							</div>
						</div>
						<div class="col-md-3">
							<label for="rating_type" class="control-label">Model</label>
							<div class="form-group">
								<input type="text" name="model" class="form-control" value="<?php echo $this->input->post('model'); ?>" />
							</div>
						</div>
					</div>
				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-success">
						<i class="fa fa-check"></i> Save
					</button>
				</div>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		$('#staff').select2({});
		$('#myform').submit(function(e) {
			if ($('#rating_type').val() == 3 && $('#reason').val() == '') {
				alert('Please give feedback before submitting');
				e.preventDefault();
				return;
			}

		});
	</script>
	<script src="<?php echo site_url('resources/js/bootstrap.min.js'); ?>"></script>
	<!-- FastClick -->
	<script src="<?php echo site_url('resources/js/fastclick.js'); ?>"></script>
	<!-- AdminLTE App -->
	<script src="<?php echo site_url('resources/js/app.min.js'); ?>"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="<?php echo site_url('resources/js/demo.js'); ?>"></script>
	<!-- DatePicker -->
	<script src="<?php echo site_url('resources/js/moment.js'); ?>"></script>
	<script src="<?php echo site_url('resources/js/bootstrap-datetimepicker.min.js'); ?>"></script>
	<script src="<?php echo site_url('resources/js/global.js'); ?>"></script>
</body>

</html>