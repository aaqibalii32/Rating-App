<table border="1" width="100%">
    <tr>
		<th>ID</th>
		<th>Forename</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Mobile Number</th>
		<th>City</th>
		<th>Vehicle Type</th>
		<th>Model</th>
		<th>Created By</th>
		<th>Date Created</th>
		<th>User Link</th>
		<th>Actions</th>
    </tr>
	<?php foreach($users as $u){ ?>
    <tr>
		<td><?php echo $u['id']; ?></td>
		<td><?php echo $u['forename']; ?></td>
		<td><?php echo $u['first_name']; ?></td>
		<td><?php echo $u['last_name']; ?></td>
		<td><?php echo $u['mobile_number']; ?></td>
		<td><?php echo $u['city']; ?></td>
		<td><?php echo $u['vehicle_type']; ?></td>
		<td><?php echo $u['model']; ?></td>
		<td><?php echo $u['created_by']; ?></td>
		<td><?php echo $u['date_created']; ?></td>
		<td><?php echo $u['user_link']; ?></td>
		<td>
            <a href="<?php echo site_url('user/edit/'.$u['id']); ?>">Edit</a> | 
            <a href="<?php echo site_url('user/remove/'.$u['id']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
