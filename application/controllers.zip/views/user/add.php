<?php echo form_open('user/add'); ?>

	<div>
		<span class="text-danger">*</span>Forename : 
		<input type="text" name="forename" value="<?php echo $this->input->post('forename'); ?>" />
		<span class="text-danger"><?php echo form_error('forename');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>First Name : 
		<input type="text" name="first_name" value="<?php echo $this->input->post('first_name'); ?>" />
		<span class="text-danger"><?php echo form_error('first_name');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>Last Name : 
		<input type="text" name="last_name" value="<?php echo $this->input->post('last_name'); ?>" />
		<span class="text-danger"><?php echo form_error('last_name');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>Mobile Number : 
		<input type="text" name="mobile_number" value="<?php echo $this->input->post('mobile_number'); ?>" />
		<span class="text-danger"><?php echo form_error('mobile_number');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>City : 
		<input type="text" name="city" value="<?php echo $this->input->post('city'); ?>" />
		<span class="text-danger"><?php echo form_error('city');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>Vehicle Type : 
		<input type="text" name="vehicle_type" value="<?php echo $this->input->post('vehicle_type'); ?>" />
		<span class="text-danger"><?php echo form_error('vehicle_type');?></span>
	</div>
	<div>
		<span class="text-danger">*</span>Model : 
		<input type="text" name="model" value="<?php echo $this->input->post('model'); ?>" />
		<span class="text-danger"><?php echo form_error('model');?></span>
	</div>
	<div>
		Created By : 
		<input type="text" name="created_by" value="<?php echo $this->input->post('created_by'); ?>" />
	</div>
	<div>
		Date Created : 
		<input type="text" name="date_created" value="<?php echo $this->input->post('date_created'); ?>" />
	</div>
	<div>
		User Link : 
		<textarea name="user_link"><?php echo $this->input->post('user_link'); ?></textarea>
	</div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>