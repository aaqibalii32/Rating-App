<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Employee Edit</h3>
            </div>
            <?php echo form_open('staff/edit/' . $staff['id']); ?>
            <div class="box-body">
                <div class="row clearfix">
                    <div class="col-md-3">
                        <label for="branch" class="control-label">Branch <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select name="branch" id="branch" class="form-control">
                                <option value="">Select Branch </option>
                                <?php
                                foreach ($branch as $b) {
                                    $selected = ($b['id'] == $staff['branch_id']) ? ' selected="selected"' : "";

                                    echo '<option value="' . $b['id'] . '" ' . $selected . '>' . $b['branch_name'] . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="full_name" class="control-label"><span class="text-danger">*</span>Full Name</label>
                        <div class="form-group">
                            <input type="text" name="full_name" value="<?php echo ($this->input->post('full_name') ? $this->input->post('full_name') : $staff['full_name']); ?>" class="form-control" id="full_name" />
                            <span class="text-danger"><?php echo form_error('full_name'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="email" class="control-label"><span class="text-danger">*</span>Email</label>
                        <div class="form-group">
                            <input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $staff['email']); ?>" class="form-control" id="email" />
                            <span class="text-danger"><?php echo form_error('email'); ?></span>
                        </div>
                    </div>
                    <!-- <div class="col-md-3">
                        <label for="password" class="control-label"><span class="text-danger">*</span>Password</label>
                        <div class="form-group">
                            <input type="text" name="password"
                                value="<?php echo ($this->input->post('password') ? $this->input->post('password') : $staff['password']); ?>"
                                class="form-control" id="password" />
                            <span class="text-danger"><?php echo form_error('password'); ?></span>
                        </div>
                    </div> -->

                    <!-- <div class="col-md-3">
                        <div class="form-group">
                            <input type="checkbox" name="is_active" value="1"
                                <?php echo ($staff['is_active'] == 1 ? 'checked="checked"' : ''); ?> id='is_active' />
                            <label for="is_active" class="control-label">Is Active</label>
                        </div>
                    </div> -->
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Save
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>