<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Employee Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('staff/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Full Name</th>
                         <th>Branch</th>
						<th>Email</th>
                       
                        <th>User Link</th>
						<th>Date Created</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($staff as $s){ ?>
                    <tr>
                        <td><?php echo $s['full_name']; ?></td>
                        <td><?php echo $s['branch_name']; ?></td>
                        <td><?php echo $s['email']; ?></td>
                        <td><a href="<?php echo base_url('rating/add/'.$s['id']) ?>"><?php echo base_url('customer/rating/'.$s['id']) ?></a></td>
						<td><?php echo $s['date_created']; ?></td>
						<td>
                            <a href="<?php echo site_url('staff/edit/'.$s['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> </a> 
                            <a href="<?php echo site_url('staff/remove/'.$s['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> </a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
