<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Branch Add</h3>
            </div>
            <?php echo form_open('branch/add'); ?>
            <div class="box-body">
                <div class="row clearfix">
                    <div class="col-md-3">
                        <label for="branch_name" class="control-label">Branch Name <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <input type="text" name="branch_name" value="<?php echo $this->input->post('branch_name'); ?>"
                                class="form-control" id="branch_name" />
                            <span class="text-danger"><?php echo form_error('branch_name');?></span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="address" class="control-label">Address</label>
                        <div class="form-group">
                            <input type="text" name="address" value="<?php echo $this->input->post('address'); ?>"
                                class="form-control" id="address" />
                            <span class="text-danger"><?php echo form_error('address');?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Save
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>